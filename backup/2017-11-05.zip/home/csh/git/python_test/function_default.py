def say(message,times=2):
	print(message*times)
say('hello ')
say('hello ',5)
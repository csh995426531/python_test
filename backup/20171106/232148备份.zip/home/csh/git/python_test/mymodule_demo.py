import mymodule

mymodule.say_hi()
print('Version',mymodule.__version__)
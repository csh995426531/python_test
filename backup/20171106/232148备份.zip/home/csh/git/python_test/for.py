for i in range(1,5):
	print(i)
else:
	print('The for loop is over')


print(list(range(1,10,2)))
array = list(range(1,10))
for a in array:
	print(a)
else:
	print('结束了')
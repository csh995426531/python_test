# from mymodule import say_hi,__version__
from mymodule import *
say_hi()
print('Version',__version__)

x = 60

def func(x):
	print('x is',x)
	x = 2 
	print('next x is',x)

func(x)
print('最终 x=',x)
def say_hi():
	print('Hi, this is mymodult speaking.')

__version__='0.1'
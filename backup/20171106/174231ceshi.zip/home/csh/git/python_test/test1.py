a=1
b=2
print(a+b)

c = "哈哈哈哈  \b哈哈哈"
print(c)

d = "呵呵呵呵\
呵呵"
print(d)


def func(a,b=1,c=2):
	print('a is',a,'and b is',b,'and c is',c)
func(11,2)
func(c=4,a=0)
func(111,c=222,b=22)